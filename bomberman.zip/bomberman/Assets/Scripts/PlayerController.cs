﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Direction { up, down, right, left }

public class PlayerController : Vunerable
{

    [SerializeField] float speed = 1;
    [SerializeField] GameObject defaultBomb;
    [SerializeField] LayerMask _default;
    [SerializeField] LayerMask ignoreBomb;
    [SerializeField] float rangeAdd = 3;
    [SerializeField] bool isPlayer1 = true;
    List<GameObject> bombs = new List<GameObject>();
    int maxBombs = 1;
    float bombRange = 3;
    float multiplicadorPercentualVelocidade = 1;
    Direction dirState = Direction.up;
    public Direction DirState
    {
        get
        {
            return dirState;
        }
    }
    CharacterController chControl;
    bool speedPowerUp = false;

    private void Start()
    {
        chControl = GetComponent<CharacterController>();
    }

    private void Update()
    {
        if (!GameManager.instance.GameOver)
        {
            Collider[] cols = Physics.OverlapBox(transform.position, transform.localScale / 2.5f);
            foreach (Collider col in cols)
            {
                if (col.tag == "PowerUp")
                {
                    switch (col.GetComponent<PowerUp>().Type)
                    {
                        case PW_type.speed:
                            if (!speedPowerUp)
                            {
                                col.GetComponent<PowerUp>().Picked();
                                multiplicadorPercentualVelocidade = 1.4f;
                                speedPowerUp = true;
                            }
                            break;

                        case PW_type.range:
                            col.GetComponent<PowerUp>().Picked();
                            bombRange += rangeAdd;
                            break;

                        case PW_type.increase:
                            col.GetComponent<PowerUp>().Picked();
                            maxBombs += 1;
                            break;
                    }
                }
            }

            if (bombs.Count > 0)
            {
                List<GameObject> toRemove = new List<GameObject>();

                for (int i = 0; i < bombs.Count; i++)
                {
                    if (bombs[i])
                    {
                        if (bombs[i].GetComponent<Bomb>().Exploded)
                        {
                            toRemove.Add(bombs[i]);
                        }
                    }
                    else
                    {
                        toRemove.Add(bombs[i]);
                    }
                }

                if (toRemove.Count > 0)
                {
                    foreach (GameObject r in toRemove)
                    {
                        bombs.Remove(r);
                    }
                }
            }

            player1(isPlayer1);
        }
    }

    void player1(bool pl)
    {
        if (pl)
        {
            if (Input.GetButtonDown("Fire1") && bombs.Count < maxBombs)
            {
                GameObject bomb = Instantiate(defaultBomb, transform.position, Quaternion.identity);
                bomb.GetComponent<Bomb>().SetBombRange(bombRange);
                bombs.Add(Instantiate(defaultBomb, transform.position, Quaternion.identity));
            }

            //cima
            if (Input.GetAxisRaw("Vertical") > 0)
            {
                dirState = Direction.up;
                chControl.SimpleMove(speed * transform.forward.normalized * multiplicadorPercentualVelocidade);
                return;
            }
            //baixo
            if (Input.GetAxisRaw("Vertical") < 0)
            {
                dirState = Direction.down;
                chControl.SimpleMove(speed * -transform.forward.normalized * multiplicadorPercentualVelocidade);
                return;
            }

            //direita
            if (Input.GetAxisRaw("Horizontal") > 0)
            {
                dirState = Direction.right;
                chControl.SimpleMove(speed * transform.right.normalized * multiplicadorPercentualVelocidade);
                return;
            }
            //esquerda
            if (Input.GetAxisRaw("Horizontal") < 0)
            {
                dirState = Direction.left;
                chControl.SimpleMove(speed * -transform.right.normalized * multiplicadorPercentualVelocidade);
                return;
            }
        }

        else
        {
            if (Input.GetButtonDown("Fire2") && bombs.Count < maxBombs)
            {
                GameObject bomb = Instantiate(defaultBomb, transform.position, Quaternion.identity);
                bomb.GetComponent<Bomb>().SetBombRange(bombRange);
                bombs.Add(Instantiate(defaultBomb, transform.position, Quaternion.identity));
            }

            //cima
            if (Input.GetAxisRaw("Vertical2") < 0)
            {
                dirState = Direction.up;
                chControl.SimpleMove(speed * transform.forward.normalized * multiplicadorPercentualVelocidade);
                return;
            }
            //baixo
            if (Input.GetAxisRaw("Vertical2") > 0)
            {
                dirState = Direction.down;
                chControl.SimpleMove(speed * -transform.forward.normalized * multiplicadorPercentualVelocidade);
                return;
            }

            //direita
            if (Input.GetAxisRaw("Horizontal2") > 0)
            {
                dirState = Direction.right;
                chControl.SimpleMove(speed * transform.right.normalized * multiplicadorPercentualVelocidade);
                return;
            }
            //esquerda
            if (Input.GetAxisRaw("Horizontal2") < 0)
            {
                dirState = Direction.left;
                chControl.SimpleMove(speed * -transform.right.normalized * multiplicadorPercentualVelocidade);
                return;
            }
        }
    }

    public override void YouAreDeadMakeYourMove()
    {
        base.YouAreDeadMakeYourMove();
    }
}
