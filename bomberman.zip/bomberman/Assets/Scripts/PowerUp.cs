﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PW_type { speed, range, increase}

public class PowerUp : MonoBehaviour {

    [SerializeField] PW_type type;
    public PW_type Type
    {
        get
        {
            return type;
        }
    }

    public void SetPWType(PW_type type)
    {
        this.type = type;
    }

    public void Picked()
    {
        Destroy(gameObject);
    }
}
