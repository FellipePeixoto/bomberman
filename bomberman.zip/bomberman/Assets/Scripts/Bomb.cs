﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bomb : Vunerable
{

    [SerializeField] float timeToExpl = 1;
    [SerializeField] float effectTime = 0.12f;
    [SerializeField] GameObject explFx;
    [SerializeField] LayerMask layerToCast;
    bool exploded = false;
    public bool Exploded
    {
        get
        {
            return exploded;
        }
    }
    bool danger = false;
    float bombRange = 3;
    GameObject[] lines;
    RaycastHit up;
    RaycastHit down;
    RaycastHit right;
    RaycastHit left;
    bool linesSetup = false;

    private void Start()
    {
        StartCoroutine(timer(timeToExpl));
    }

    private void FixedUpdate()
    {
        if (danger)
        {
            GameManager.instance.DestroyObjsStack(CastExpl(transform.position, bombRange));
        }
    }

    IEnumerator timer(float time)
    {
        yield return new WaitForSeconds(time);
        danger = true;
        GetComponent<SphereCollider>().enabled = false;
        yield return new WaitForFixedUpdate();
        SetUpExplFx();
        yield return new WaitForSeconds(effectTime);
        exploded = true;
        danger = false;
        DestroyLines();
        Destroy(gameObject);
    }

    RaycastHit[] CastExpl(Vector3 position, float range)
    {
        up = CastRay(position, Vector3.forward, range);
        down = CastRay(position, Vector3.back, range);
        right = CastRay(position, Vector3.right, range);
        left = CastRay(position, Vector3.left, range);

        return new RaycastHit[4] { up, down, right, left };
    }

    RaycastHit CastRay(Vector3 position, Vector3 direction, float range)
    {
        RaycastHit ray = new RaycastHit();
        Physics.Raycast(new Ray(position, direction), out ray, range, layerToCast);
        return ray;
    }

    void SetUpExplFx()
    {
        linesSetup = true;
        lines = new GameObject[4];
        lines[0] = Instantiate(explFx, transform.position, Quaternion.identity);
        lines[1] = Instantiate(explFx, transform.position, Quaternion.identity);
        lines[2] = Instantiate(explFx, transform.position, Quaternion.identity);
        lines[3] = Instantiate(explFx, transform.position, Quaternion.identity);
        lines[0].GetComponent<LineRendererController>().SetDestiny(up.point);
        lines[1].GetComponent<LineRendererController>().SetDestiny(down.point);
        lines[2].GetComponent<LineRendererController>().SetDestiny(right.point);
        lines[3].GetComponent<LineRendererController>().SetDestiny(left.point);
    }

    void DestroyLines()
    {
        Destroy(lines[0]);
        Destroy(lines[1]);
        Destroy(lines[2]);
        Destroy(lines[3]);
    }

    IEnumerator ExplodeByOther()
    {
        danger = true;
        GetComponent<BoxCollider>().enabled = false;
        yield return new WaitForFixedUpdate();
        if (!linesSetup)
            SetUpExplFx();
        yield return new WaitForSeconds(effectTime);
        exploded = true;
        danger = false;
        DestroyLines();
        Destroy(gameObject);
    }

    public override void YouAreDeadMakeYourMove()
    {
        StopAllCoroutines();
        StartCoroutine(ExplodeByOther());
    }

    public void SetBombRange(float range)
    {
        bombRange = range;
    }
}
