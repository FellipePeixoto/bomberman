﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BreakableBlock : Vunerable
{

    [SerializeField] GameObject[] powerUps;

    public override void YouAreDeadMakeYourMove()
    {
        int index = Random.Range(0, powerUps.Length * 4);
        if (index < powerUps.Length)
        {
            GameObject x = Instantiate(powerUps[index], transform.position + Vector3.up * 0.8f, Quaternion.identity);
        }
        base.YouAreDeadMakeYourMove();
    }
}