﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vunerable : MonoBehaviour {

    /// <summary>
    /// ZOERA
    /// </summary>
	public virtual void YouAreDeadMakeYourMove()
    {
        Destroy(gameObject);
    }
}
