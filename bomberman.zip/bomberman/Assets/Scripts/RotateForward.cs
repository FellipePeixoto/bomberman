﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateForward : MonoBehaviour {

    [SerializeField] PlayerController myPlayer;

	// Update is called once per frame
	void Update ()
    {
        switch (myPlayer.DirState)
        {
            case Direction.up:
                transform.LookAt(transform.position + Vector3.forward);
                return;

            case Direction.down:
                transform.LookAt(transform.position + Vector3.back);
                return;

            case Direction.right:
                transform.LookAt(transform.position + Vector3.right);
                return;

            case Direction.left:
                transform.LookAt(transform.position + Vector3.left);
                return;
        }
	}
}
