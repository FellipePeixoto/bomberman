﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

	public static GameManager instance;
    bool gameOver = false;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }
        DontDestroyOnLoad(gameObject);
    }

    private void FixedUpdate()
    {
        if (gameOver)
        {
            if (Input.GetButtonDown("Submit"))
            {
                GameObject.FindWithTag("Display").GetComponent<Text>().text = "";
                gameOver = false;
                SceneManager.LoadScene("cenaA");
            }
        }
    }

    public bool GameOver
    {
        get
        {
            return gameOver;
        }
    }

    public void CallGameOver(string vencedor)
    {
        GameObject.FindWithTag("Display").GetComponent<Text>().text = vencedor;
        gameOver = true;
    }

    public void DestroyObjsStack(RaycastHit[] hitsToCheck)
    {
        foreach(RaycastHit v in hitsToCheck)
        {
            if (v.transform)
            {
                if (v.transform.gameObject.GetComponent<Vunerable>())
                {
                    if (!(v.transform.gameObject.GetComponent<Vunerable>().tag == "Player") && !(v.transform.gameObject.GetComponent<Vunerable>().tag == "Player2"))
                    {
                        v.transform.gameObject.GetComponent<Vunerable>().YouAreDeadMakeYourMove();                        
                    }
                    else
                    {
                        if (v.transform.gameObject.GetComponent<Vunerable>().tag == "Player")
                            CallGameOver("Player 2 venceu o jogo. Aperte Enter para recomeçar");
                        else
                            CallGameOver("Player 1 venceu o jogo. Aperte Enter para recomeçar");
                    }
                }
            }
        }
    }
}
