﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class LineRendererController : MonoBehaviour {

    LineRenderer line;
    Vector3 destiny = Vector3.zero;

    private void Awake()
    {
        line = GetComponent<LineRenderer>();
    }

    private void Start()
    {
        line.SetPosition(0, transform.position);
        line.SetPosition(1, destiny);        
    }

    public void SetDestiny(Vector3 destiny)
    {
        this.destiny = destiny;
    }
}
